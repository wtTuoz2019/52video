
<link rel="stylesheet" href="qdq_plug/images/qdqcss.css" type="text/css">
<div class="sign ui transition hidden" id="sign">
<div class="sign-butt ui vertical labeled icon buttons">
<div class="ui blue button" id="start-action">
      <i class="play icon"></i>
      开始活动
  </div>
 </div>
 
</div>
<script type="text/javascript" src="js/qdq_xiaobai.js"></script>
