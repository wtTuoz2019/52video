<link rel="stylesheet" type="text/css" href="style/<?php echo $style?>/css/component.css" />
<div class="container demo-2">
	<div class="content">
		<div id="large-header" class="large-header">
			<canvas id="demo-canvas"></canvas>
		</div>
	</div>
</div>

<script src="style/<?php echo $style?>/js/demo-2.js"></script>
<script src="style/<?php echo $style?>/js/rAF.js"></script>