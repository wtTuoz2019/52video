<script src="js/jquery.localscroll-1.2.7-min.js"></script>
<script src="js/jpreloader.min.js"></script>
<script src="js/jquery.videobg.custom.js"></script>
<script src="style/<?php echo $style?>/js/<?php echo $style?>.min.js"></script>
	<div id="hero-unit" class="hero-unit hero-light hero-video"></div>
